Asset Pack Title: Simple Sand - RPG / Topdown Tileset
Category: Tileset
Graphic Style: Retro, pixel

This tileset is suitable for a western-style gunslinging action topdown shooter or a small sand/desert location for an rpg.

--

This package contains:
- 12 unique tiles; 32x32 each
- 1x, 2x, and 3x scale
- Sliced version of the 1x scale

--

How to use:
- Extract the tileset
- Import the tileset in your game editor and make sure to set the tile dimensions to 32x32